package cn.spring.pojo;

import lombok.Data;

@Data
public class Hello {
    private  String str;

}
