package cn.wugou.demo02;

public interface UserService {
    public void select();

    public void delete();

    public void update();

    public void insert();
}
