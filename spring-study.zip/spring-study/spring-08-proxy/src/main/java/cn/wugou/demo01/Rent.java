package cn.wugou.demo01;

//租房
public interface Rent {
    public void  rent();
}
