package cn.wugou.dao;

import cn.wugou.pojo.User;

import java.util.List;

public interface UserMapper {
    public List<User> getList();
}
