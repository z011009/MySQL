package cn.wugou.dao;

import lombok.Data;

@Data
public class Address {
    private String address;
}
