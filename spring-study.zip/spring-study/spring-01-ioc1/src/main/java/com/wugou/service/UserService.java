package com.wugou.service;

public interface UserService {
    void  getUser();
}
