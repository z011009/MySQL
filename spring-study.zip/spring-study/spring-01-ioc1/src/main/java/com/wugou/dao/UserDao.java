package com.wugou.dao;

public interface UserDao {
    void getUser();
}
