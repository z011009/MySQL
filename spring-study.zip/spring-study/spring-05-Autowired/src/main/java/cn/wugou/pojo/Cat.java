package cn.wugou.pojo;

public class Cat {
    public void call() {
        System.out.println("喵喵喵......");
    }
}
