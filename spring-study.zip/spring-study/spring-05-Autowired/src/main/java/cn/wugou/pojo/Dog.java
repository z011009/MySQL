package cn.wugou.pojo;

public class Dog {
    public void call(){
        System.out.println("汪汪汪......");
    }
}
