package cn.wugou.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
}
